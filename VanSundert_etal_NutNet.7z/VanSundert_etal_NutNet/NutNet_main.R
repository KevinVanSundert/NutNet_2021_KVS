
########################################

  # Read in data & calculate 
  # nANPP and Diff_X

########################################

TBL = read.table('main.txt',header=T)

library(dplyr)

NewTBL=group_by(TBL,site)
NewTBL=mutate(NewTBL,diff_gdd=gdd-mean(gdd))
NewTBL=ungroup(NewTBL)

NewTBL=group_by(NewTBL,site)
NewTBL=mutate(NewTBL,diff_wb=wb-mean(wb))
NewTBL=ungroup(NewTBL)

NewTBL=group_by(NewTBL,site)
NewTBL=mutate(NewTBL,diff_is=is-mean(is))
NewTBL=ungroup(NewTBL)

NewTBL=group_by(NewTBL,site)
NewTBL=mutate(NewTBL,diff_ppt=ppt-mean(ppt))
NewTBL=ungroup(NewTBL)

NewTBL=group_by(NewTBL,site,plot)
NewTBL=mutate(NewTBL,nANPP_comm=(m_comm+0.1)/mean(m_comm+0.1))
NewTBL=ungroup(NewTBL)

NewTBL=group_by(NewTBL,site,plot)
NewTBL=mutate(NewTBL,nANPP_forb_nonleg=(m_forb_nonleg+0.1)/mean(m_forb_nonleg+0.1))
NewTBL=ungroup(NewTBL)

NewTBL=group_by(NewTBL,site,plot)
NewTBL=mutate(NewTBL,nANPP_gramin=(m_gramin+0.1)/mean(m_gramin+0.1))
NewTBL=ungroup(NewTBL)

NewTBL=group_by(NewTBL,site,plot)
NewTBL=mutate(NewTBL,nANPP_legume=(m_legume+0.1)/mean(m_legume+0.1))
NewTBL=ungroup(NewTBL)

NewTBL=group_by(NewTBL,site,plot)
NewTBL=mutate(NewTBL,nANPP_forb=(m_forb+0.1)/mean(m_forb+0.1))
NewTBL=ungroup(NewTBL)

NewTBL=group_by(NewTBL,site,plot)
NewTBL=mutate(NewTBL,nANPP_gh_ratio=(gh_ratio+0.001)/mean(gh_ratio+0.001))
NewTBL=ungroup(NewTBL)

NewTBL = as.data.frame(NewTBL)
attach(NewTBL)

# Interannual focus
NewTBL$year = as.factor(NewTBL$year)
library(lmerTest)
y = log(NewTBL$nANPP_gramin)
x1 = NewTBL$diff_gdd
x2 = NewTBL$diff_is
ftrt = NewTBL$trt
ftrto = NewTBL$trt_other
RANDOM1 = NewTBL$site
RANDOM2 = NewTBL$year # nested in site (year does not have the same effect everywhere)
RANDOM3 = NewTBL$plot # nested in site, treatment and other treatment

lm1 = lmer(y ~ x1 + x2 + ftrt + ftrto + x1:x2 + x1:ftrt + x1:ftrto + x2:ftrt + x2:ftrto + ftrt:ftrto + x1:x2:ftrt + (1|RANDOM1) + (1|RANDOM2:RANDOM1) + (1|RANDOM3:RANDOM1) + (1|RANDOM3:ftrt) + (1|RANDOM3:ftrto))

lm1 = lmer(y ~ x2 + ftrt + ftrto + x2:ftrt + x2:ftrto + ftrt:ftrto + (1|RANDOM1) + (1|RANDOM2:RANDOM1) + (1|RANDOM3:RANDOM1) + (1|RANDOM3:ftrt) + (1|RANDOM3:ftrto))

anova(lm1)
summary(lm1)

library(MuMIn)
r.squaredGLMM(lm1)

# Focus on year 2018

FTBL = filter(NewTBL,year=="2018")
FTBL = as.data.frame(FTBL)
attach(FTBL)

library(lmerTest)
y = log(FTBL$nANPP_gramin)
x1 = FTBL$diff_gdd
x2 = FTBL$diff_is
ftrt = FTBL$trt
ftrto = FTBL$trt_other
RANDOM1 = FTBL$site

ftrt = factor(ftrt, levels = c("NPK","N","K","Control","NK","NP","PK","P"))
levels(ftrt)

lm1 = lmer(y ~ x1 + x2 + ftrt + ftrto + x1:x2 + x1:ftrt + x1:ftrto + x2:ftrt + x2:ftrto + ftrt:ftrto + x1:x2:ftrt + (1|RANDOM1))

lm1 = lmer(y ~ x2 + ftrt + ftrto + x2:ftrt + x2:ftrto + ftrt:ftrto + (1|RANDOM1))

anova(lm1)
summary(lm1)

library(MuMIn)
r.squaredGLMM(lm1)

# Overall treatment effect on biomass

library(lmerTest)
y = log(NewTBL$m_gramin)
ftrt = NewTBL$trt
ftrto = NewTBL$trt_other
RANDOM1 = NewTBL$site
RANDOM2 = NewTBL$year # nested in site (year does not have the same effect everywhere)
RANDOM3 = NewTBL$plot # nested in site, treatment and other treatment

lm1 = lmer(y ~ ftrt + ftrto + ftrt:ftrto + (1|RANDOM1) + (1|RANDOM2:RANDOM1) + (1|RANDOM3:RANDOM1) + (1|RANDOM3:ftrt) + (1|RANDOM3:ftrto))

anova(lm1)
summary(lm1)

library(glmmTMB)
lm1 = glmmTMB(y ~ ftrt + ftrto + ftrt:ftrto + (1|RANDOM1) + (1|RANDOM2:RANDOM1) + (1|RANDOM3:RANDOM1) + (1|RANDOM3:ftrt) + (1|RANDOM3:ftrto), family=list(family="beta",link="logit"))

glmmTMB:::Anova.glmmTMB(lm1)
summary(lm1)

##############################
##############################

detach(NewTBL)
rm(list=ls())
